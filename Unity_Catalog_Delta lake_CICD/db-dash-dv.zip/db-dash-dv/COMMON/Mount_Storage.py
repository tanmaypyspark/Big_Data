# Databricks notebook source
# MAGIC %run ./Conf

# COMMAND ----------

#Remove all existing values
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text('container_name','')
dbutils.widgets.text('mount_point','')

container = dbutils.widgets.get('container_name')
mountPoint = dbutils.widgets.get('mount_point')

# COMMAND ----------

print(container, mountPoint)

# COMMAND ----------

Conf = genConf()
keyvault = Conf['keyvault']
storageAcc = Conf['storageAcc']

# COMMAND ----------

applicationId = dbutils.secrets.get(keyvault,'ApplicationID')
objectID = dbutils.secrets.get(keyvault,'ObjectID')
tenantId = dbutils.secrets.get(keyvault,'TenantID')
clientSecret = dbutils.secrets.get(keyvault,'ClientSecret')

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": applicationId,
          "fs.azure.account.oauth2.client.secret": clientSecret,
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenantId}/oauth2/token"}

# Optionally, you can add <directory-name> to the source URI of your mount point.
dbutils.fs.mount(
    source = f"abfss://{container}@{storageAcc}.dfs.core.windows.net/",
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------


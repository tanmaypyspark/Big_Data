# Databricks notebook source
def genConf():
    get_dict = {'container': 'dash',
                'keyvault':'key20241dv',
                'storageAcc':'sa202401dv',
                'root': '/mnt/'}
    return get_dict

# COMMAND ----------


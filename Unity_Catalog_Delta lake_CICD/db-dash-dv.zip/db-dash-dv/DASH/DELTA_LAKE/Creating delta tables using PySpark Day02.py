# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','deltalake/target/parq/')
source_path = dbutils.widgets.get('PATH')
#layer
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','ParqutFolder')
file_name = dbutils.widgets.get('FILE')
# deltalake / target / delta / deltaFolder

# COMMAND ----------

### CONF Details #####
conf = genConf()
root = conf['root']
delta_path = root+ source_path + file_name

# COMMAND ----------

delta_path

# COMMAND ----------

# MAGIC %md 
# MAGIC #Read Delta file

# COMMAND ----------

df = spark.read.format('parquet').load(delta_path)

# COMMAND ----------

df.count()

# COMMAND ----------

df.write.format('delta').mode('overwrite').saveAsTable('`delta`.deltaSpark')

# COMMAND ----------

display(dbutils.fs.ls('abfss://unity-catalog-storage@dbstorage5ehqsmyq5yvnc.dfs.core.windows.net/907948701524827/__unitystorage/'))

# COMMAND ----------


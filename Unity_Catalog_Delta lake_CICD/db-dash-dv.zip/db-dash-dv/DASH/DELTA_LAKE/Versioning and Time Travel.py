# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','deltalake/raw/')
source_path = dbutils.widgets.get('PATH')
#layer ce/schemaEvol/SchemaLessCols.csv
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','SchemaManagementDelta.csv')
file_name = dbutils.widgets.get('FILE')
# deltalake / target / delta / deltaFolder

### CONF Details #####
conf = genConf()
root = conf['root']
path = root+ source_path + file_name
path

# COMMAND ----------

schema1 = StructType([
    StructField('Education_Level',StringType()),
    StructField('Line_Number',IntegerType()),
    StructField('Employed',IntegerType()),
    StructField('Unemployed',IntegerType()),
    StructField('Industry',StringType()),
    StructField('Gender',StringType()),
    StructField('Date_Inserted',StringType()),
    StructField('dense_rank',IntegerType())
])

# COMMAND ----------

schema_df = spark.read.format('csv')\
    .option('header','True')\
        .schema(schema1)\
            .load(path)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS unity_test.delta2

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from `delta`.versionTable

# COMMAND ----------

# MAGIC %md
# MAGIC #Inserting Records In The Table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `delta`.versionTable
# MAGIC VALUES 
# MAGIC       ('Bachelor',1,4500,500,'Networking','Male','2023-07-12',1),
# MAGIC       ('Master',2,6500,500,'Networking','Female','2023-07-12',2),
# MAGIC       ('High School',3,3500,500,'Networking','Male','2023-07-12',3),
# MAGIC       ('PhD',4,5500,500,'Networking','Female','2023-07-12',4)

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history `delta`.versionTable

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE `delta`.versionTable
# MAGIC SET Education_Level = 'PhD'
# MAGIC WHERE Industry = 'Networking'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from `delta`.versionTable where Industry ='Networking'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from `delta`.versionTable where Industry ='Networking'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `delta`.versionTable VERSION AS OF 3 where Industry ='Networking'

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.lastCommitVersionInSession

# COMMAND ----------


# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','deltalake/target/')
source_path = dbutils.widgets.get('PATH')
#layer
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','')
file_name = dbutils.widgets.get('FILE')
# deltalake / target / delta / deltaFolder

# COMMAND ----------

### CONF Details #####
conf = genConf()
root = conf['root']
delta_path = root+ source_path + file_name

# COMMAND ----------

# MAGIC %md
# MAGIC #create schema(database)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS delta

# COMMAND ----------

# MAGIC %sql
# MAGIC --CREATE TABLE
# MAGIC CREATE OR REPLACE TABLE `delta`.deltaFile
# MAGIC (
# MAGIC   Education_Level VARCHAR(50),
# MAGIC   Line_Number INT,
# MAGIC   Employed INT,
# MAGIC   Unemployed INT,
# MAGIC   Industry VARCHAR(50),
# MAGIC   Gender VARCHAR(10),
# MAGIC   Date_Inserted DATE,
# MAGIC   dense_rank INT
# MAGIC )

# COMMAND ----------

# MAGIC %md 
# MAGIC #Adding records to delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `delta`.deltaFile 
# MAGIC VALUES
# MAGIC ('Bachelor',1,4500,500,'IT','Male','2023-07-12',1),
# MAGIC ('Master',2,6500,500,'Finance','Female','2023-07-12',2),
# MAGIC ('High School',3,3500,500,'Retail','Male','2023-07-12',3),
# MAGIC ('PhD',4,5500,500,'Healthcare','Female','2023-07-12',4)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Update data in table

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE `delta`.deltaFile
# MAGIC SET Industry = 'Finance'
# MAGIC where Education_Level = 'PhD'

# COMMAND ----------

dbutils.fs.ls('abfss://unity-catalog-storage@dbstorage5ehqsmyq5yvnc.dfs.core.windows.net/907948701524827/')

# COMMAND ----------


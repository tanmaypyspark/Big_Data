-- Databricks notebook source
-- MAGIC %python
-- MAGIC display(dbutils.fs.mounts())

-- COMMAND ----------

-- MAGIC %python
-- MAGIC def read_file(file_name,tbl_name):
-- MAGIC     df = spark.read.format('csv').option('header','true').option('inferSchema','true').load(f'/mnt/dummy/{file_name}.csv')
-- MAGIC     df.createOrReplaceTempView(f'{tbl_name}')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC print(dbutils.fs.ls('/mnt'))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df_mock_data = spark.read.format('csv').option('header','true').option('inferSchema','true').load('/mnt/dummy/MOCK_DATA.csv')
-- MAGIC df_data = spark.read.format('csv').option('header','true').option('inferSchema','true').load('/mnt/dummy/DATA.csv')
-- MAGIC df_orderID = spark.read.format('csv').option('header','true').option('inferSchema','true').load('/mnt/dummy/orderID.csv')
-- MAGIC df_customerID = spark.read.format('csv').option('header','true').option('inferSchema','true').load('/mnt/dummy/customerID.csv')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df_mock_data.createOrReplaceTempView('Emp_mock')
-- MAGIC df_data.createOrReplaceTempView('Emp')
-- MAGIC df_orderID.createOrReplaceTempView('orderID')
-- MAGIC df_customerID.createOrReplaceTempView('customer')

-- COMMAND ----------

select * from Emp_mock;

-- COMMAND ----------

select * from orderID limit 1;

-- COMMAND ----------

--1. Write a sql query to find the average purchase amount for each customer. Assume you have two tables: customer(customerID, name) and orders(OrderId,CustomerID,Amount)

select c.CustomerID,c.Name, avg(o.Amount) as AvgPurches from customer c
join orderID o on c.CustomerID = o.CustomerID group by c.CustomerID,c.Name order by c.CustomerID


-- COMMAND ----------

select * from ( select * from (select *, dense_rank() over(partition by dept_name order by salary desc) as rank from emp));

-- COMMAND ----------

--2.waq to find the employee with the minimum dalary in each department from a table
with cte as (select *, dense_rank() over(partition by dept_name order by salary desc) as rn from emp),
max_rank as (select dept_name, max(rn) as rank from cte group by dept_name)

select c.emp_id, concat(c.first_name,' ',c.last_name ) as name, c.email, c.gender, c.dept_name, c.salary from cte c 
inner join max_rank m  on c.rn = m.rank and c.dept_name=m.dept_name;

-- COMMAND ----------

select e1.emp_id, e1.dept_name,concat(e1.first_name,' ',e1.last_name ) as name, e1.salary from emp e1
where salary = (select min(salary) from emp e2
where e2.dept_name = e1.dept_name)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC df = read_file('product','product')
-- MAGIC
-- MAGIC df2 = read_file('sales','sales')

-- COMMAND ----------

select * from sales

-- COMMAND ----------

-- 3. WAQ TF all products that have never been sold. assume u have a table product(id,name) and table sales(id,pid,quenty)

select p.ProductId, p.ProductName,s.ProductID from product p
left join sales s on p.ProductId = s.ProductID
where s.ProductId is NULL

-- COMMAND ----------

-- 4. WAQ TF customer with highest total order quenty
select c.CustomerID, sum(s.Quentity) as TotalQuenty from customer c
join sales s on c.CustomerID = s.ProductID group by c.CustomerID
order by TotalQuenty desc
limit 1


-- COMMAND ----------

--5.WAQ TF the earliest order date for each customer from a table orders

select cusID, min(orderDate) as earliestOrderDate from orderr group by custID;

-- COMMAND ----------

--6. WAQ TF the number of direct reports for each manager
select managerId, count(*) as numberOfReportes from emp where managerId is not null group by managerID

-- COMMAND ----------

--7. WAQ TF cusotmers who placed their first order within the last 30 days
select c.custID,c.name from customer c
join orders o on c.custId=o.custID
where o.orderDate = (select min(o2.orderDate) from orders o2 where o2.custId = c.custID)
and o.orderDate >= current_date - interval '30 day';

-- COMMAND ----------

--Find duplicates records
select emno,ename,sal,dept_name,count(*) from emp
group by emno,ename,sal,dept_name
having count(*)>1;

-- COMMAND ----------

--WAQ to delete duplicate records from a table while keeping one copy of each
with emp_cte as (select*, row_number() over(partition by deptno order by empno) rwnum from emp)

delete from emp_cte where rwnum>1

-- COMMAND ----------

--delete duplicate records
DELETE FROM customers
WHERE customer_id IN (
  SELECT customer_id
  FROM customers
  GROUP BY customer_id
  HAVING COUNT(*) > 1
);

-- COMMAND ----------

select * from emp;

-- COMMAND ----------

select * from emp where salary %2 <>0;

-- COMMAND ----------

--more than 2 order
SELECT c.customer_id, c.customer_name
FROM customers c
INNER JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id,  
 c.customer_name
HAVING COUNT(*) > 2;

-- COMMAND ----------

create table `hive_metastore`.`default`.`swipe`(
  employee_id int,
  activity_type varchar(10),
  activity_time timestamp 
);

-- COMMAND ----------

insert into `hive_metastore`.`default`.`swipe` (employee_id,activity_type,activity_time)
values
(1, 'login', '2024-07-23 08:00:00'),
(1, 'logout', '2024-07-23 12:00:00'),
(1, 'login', '2024-07-23 13:00:00'),
(1, 'logout', '2024-07-23 17:00:00'),
(2, 'login', '2024-07-23 09:00:00'),
(2, 'logout', '2024-07-23 11:00:00'),
(2, 'login', '2024-07-23 12:00:00'),
(2, 'logout', '2024-07-23 15:00:00'),
(1, 'login', '2024-07-24 08:30:00'),
(1, 'logout', '2024-07-24 12:30:00'),
(2, 'login', '2024-07-24 09:30:00'),
(2, 'logout', '2024-07-24 10:30:00');



-- COMMAND ----------

select * from hive_metastore.default.swipe;

-- COMMAND ----------


select employee_id, date_format(activity_time,'yyyy-MM-dd') as activity_Day,
sum(datediff(hour,logot ,logi )) as total_hours,
logot,logi
 from cte group by employee_id, activity_Day;

-- COMMAND ----------

--1. Find out the time employee spent in office on a particular day(office hourse = last login - first login)
with cte as (select *, 
max(activity_time) over( partition by employee_id,date_format(activity_time,'yyyy-MM-dd')) as logot, 
min(activity_time) over( partition by employee_id,date_format(activity_time,'yyyy-MM-dd')) as logi 
from  hive_metastore.default.swipe)

select distinct employee_id, date_format(activity_time,'yyyy-MM-dd') as activity_Day,
date_diff(hour,logi ,logot ) as total_hours,
case
when activity_type !='logout'
then date_diff(hour,logi ,logot )
end
as productive_hours
from cte group by  employee_id,activity_Day;


-- COMMAND ----------

--2. Find out how much productive he was at office on a particular day. (He might have done many swipes per day. I need to find the actual time spent at office)
with cte as (
  select*,
  lead(activity_type,1,activity_type)
  over(partition by employee_id,date_format(activity_time,'yyyy-MM-dd') order by(select 1)) as next_activity,
  lead(activity_time,1,activity_time)
  over(partition by employee_id,date_format(activity_time,'yyyy-MM-dd') order by(select 1)) as next_activity_time
  from hive_metastore.default.swipe
)
select employee_id, date_format(activity_time,'yyyy-MM-dd') as activity_day,
sum(date_diff(hour,activity_time ,next_activity_time) ) as total_hours,
sum(case when activity_type !='logout' then date_diff(hour,activity_time ,next_activity_time ) end) as productive_hours 
from cte
group by employee_id, activity_day;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC data1 = [(1,), (2,), (None,), (3,), (3,), (4,), (5,)]
-- MAGIC data2 = [(1,), (1,), (None,), (2,), (2,), (3,), (5,)]
-- MAGIC schema1 = ["id"]
-- MAGIC df_tbl1 = spark.createDataFrame(data1,schema1)
-- MAGIC df_tbl2 = spark.createDataFrame(data2,schema1)
-- MAGIC df_tbl1.createOrReplaceTempView('tbl1')
-- MAGIC df_tbl2.createOrReplaceTempView('tbl2')

-- COMMAND ----------

select t1.id from tbl1 t1
full outer join tbl2 t2 on t1.id =t2.id

-- COMMAND ----------

-- MAGIC %python
-- MAGIC stri = 'TANMAY'
-- MAGIC print(list(stri))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC print({1,1,2,3})

-- COMMAND ----------


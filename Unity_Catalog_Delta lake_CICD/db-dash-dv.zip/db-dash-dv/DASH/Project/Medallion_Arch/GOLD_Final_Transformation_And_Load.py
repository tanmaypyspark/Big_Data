# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

##Input Param to run the notebook
dbutils.widgets.text('Parameter',"{'null':'null'}")
param_dict = dbutils.widgets.get('Parameter')
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':5,'run_type':'Fresh Run'}

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import ast
import datetime

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)
param

# COMMAND ----------

env= param['ENV']
checkpoints = param['checkpoints']
source_path = param['source_path']
target_path = param['target_path']
debug = param['Debug']

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read Silver_Traffic Table

# COMMAND ----------

def read_silverTraffic():
    print('Read Silver Traffic Table ', end=' ')

    df = (spark.readStream
          .format('delta')
          .table(f"`{env}_catalog`.`silver`.`silver_traffic`"))
    print('Success!!!')
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read Silver_roads Table

# COMMAND ----------

def read_silverRoads():
    print('Read Silver Roads Table ', end=' ')

    df = (spark.readStream
          .format('delta')
          .table(f"`{env}_catalog`.`silver`.`silver_roads`"))
    print('Success!!!')
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ##Creating Vehicle Intensity

# COMMAND ----------

def vehicleIntensity(df):
    print('Creating Vehicles Intensity Column: ', end=' ')
    #Motor_Vehicles_Count
    df = df.withColumn('Vehicle_Intensity',(col('Motor_Vehicles_Count')/col('Link_length_km')))
    print('Sucesss!!')

    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create a Load Time

# COMMAND ----------

def CreateLoadTime(df):
    print('Creating a Load Time Columns: ', end=' ')

    df = df.withColumn('Load_Time',current_timestamp())

    print('Success!!!')
    print("***********************")

    return df

# COMMAND ----------

##Writing to the gold_traffic tables

def writting_gold_traffic(streamDF, env,debug=0):
    print('Writting to gold traffic tables...')

    df_streamDF = streamDF.writeStream\
        .format('delta')\
            .option('checkpointLocation',f'{checkpoints}/GoldTraffic/Checkpt')\
                .outputMode('append')\
                    .queryName('GoldTrafficWriteStream')\
                        .trigger(availableNow = True)\
                            .toTable(f"`{env}_catalog`.`gold`.`gold_traffic`")
    
    df_streamDF.awaitTermination()
    print('Writting the gold_traffic Data:', end = ' ')
    print('Success!!! ')
    
    if debug ==5:
        print('Write to ADLS Silver Path......')
        time_stamp = datetime.datetime.utcnow()
        print('TimeStamp: ', time_stamp)
        df_Adls = (streamDF.writeStream
               .format('delta')
               .option('mergeSchema','true')
               .option('checkpointLocation',f'{checkpoints}/Debug/GoldTraffic/{time_stamp}/')
               .outputMode('append')
               .trigger(availableNow = True)
               .start(f'{target_path}/Debug/GoldTrafficRoads/{time_stamp}/')
            )
        df_Adls.awaitTermination()

# COMMAND ----------

##Writing to the silver_roads tables

def writting_gold_Roads(streamDF, env,debug=0):
    print('Writting to gold roads tables...')

    df_streamDF = streamDF.writeStream\
        .format('delta')\
            .option('checkpointLocation',f'{checkpoints}/GoldRoads/Checkpt')\
                .outputMode('append')\
                    .queryName('GoldRoadWriteStream')\
                        .trigger(availableNow = True)\
                            .toTable(f"`{env}_catalog`.`gold`.`gold_roads`")
    
    df_streamDF.awaitTermination()
    print('Writting the gold_roads Data:', end = ' ')
    print('Success!!! ')
    
    if debug ==5:
        print('Write to ADLS Gold Path......')
        time_stamp = datetime.datetime.utcnow()
        print('TimeStamp: ', time_stamp)
        df_Adls = (streamDF.writeStream
               .format('delta')
               .option('mergeSchema','true')
               .option('checkpointLocation',f'{checkpoints}/Debug/goldRoads/{time_stamp}/')
               .outputMode('append')
               .trigger(availableNow = True)
               .start(f'{target_path}/Debug/goldRoads/{time_stamp}/')
            )
        df_Adls.awaitTermination()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calling All the functions at once

# COMMAND ----------

##Calling silver_traffic
df_traf = read_silverTraffic()

##Calling Silver Roads
df_roads = read_silverRoads()

##Creating Vehicles Intensity
df_Vechical = vehicleIntensity(df_traf)

##Create a LaodTime
df_traffic_Final = CreateLoadTime(df_Vechical)
df_roads_Final = CreateLoadTime(df_roads)

##Write the data
df_traffic = writting_gold_traffic(df_traffic_Final,env, debug)

df_roads = writting_gold_Roads(df_roads_Final,env, debug)

# COMMAND ----------


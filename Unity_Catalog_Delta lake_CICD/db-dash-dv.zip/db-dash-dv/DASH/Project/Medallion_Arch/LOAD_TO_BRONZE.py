# Databricks notebook source
#dbutils.widgets.removeAll()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from pyspark.sql.functions import current_timestamp

# COMMAND ----------

dbutils.widgets.text('Parameter','')
param_dict = dbutils.widgets.get('Parameter')
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':5,'run_type':'Fresh Run'}

# COMMAND ----------

import json
import ast

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)

# COMMAND ----------

chk_point = param['CHKPoint']
chk_point_xt = param['CHKPointXT']
env = param['ENV']
debug = param['Debug']

if 'run_type' in param:
    if param['run_type'] == 'Fresh Run':
        try:
            df_rawTraffic = spark.sql(f""" DELETE  FROM `{env}_catalog`.`bronze`.raw_traffic""")
            df_rawRoads = spark.sql(f""" DELETE FROM `{env}_catalog`.`bronze`.raw_roads""")
        except Exception as e:
            print(f'Error: While deleting the table for Fresh Run {e}')

# COMMAND ----------

# MAGIC %md
# MAGIC #Read Streaming File

# COMMAND ----------

# MAGIC %md
# MAGIC 01 Read Traffic data

# COMMAND ----------

##Paths
landing_paths = param['landing_paths']
check_points_path = param['checkpoints']
print(f'Landing Path:{landing_paths} \nCheck Points: {check_points_path}')

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create a read_traffic_data() function

# COMMAND ----------

##Schema
def read_Traffic_Data():
    '''This function is gonna read the row traffic data from landing container'''
    print("Reading the Raw Traffic Data :  ", end='')
    schema = StructType([
    StructField("Record_ID",IntegerType()),
    StructField("Count_point_id",IntegerType()),
    StructField("Direction_of_travel",StringType()),
    StructField("Year",IntegerType()),
    StructField("Count_date",StringType()),
    StructField("hour",IntegerType()),
    StructField("Region_id",IntegerType()),
    StructField("Region_name",StringType()),
    StructField("Local_authority_name",StringType()),
    StructField("Road_name",StringType()),
    StructField("Road_Category_ID",IntegerType()),
    StructField("Start_junction_road_name",StringType()),
    StructField("End_junction_road_name",StringType()),
    StructField("Latitude",DoubleType()),
    StructField("Longitude",DoubleType()),
    StructField("Link_length_km",DoubleType()),
    StructField("Pedal_cycles",IntegerType()),
    StructField("Two_wheeled_motor_vehicles",IntegerType()),
    StructField("Cars_and_taxis",IntegerType()),
    StructField("Buses_and_coaches",IntegerType()),
    StructField("LGV_Type",IntegerType()),
    StructField("HGV_Type",IntegerType()),
    StructField("EV_Car",IntegerType()),
    StructField("EV_Bike",IntegerType())
    ])

    rawTraffic_stream = (spark.readStream\
        .format('cloudFiles')\
            .option('cloudFiles.format','csv')\
                .option('cloudFiles.schemaLocation',f'{check_points_path}/rawTrafficLoad/SchemaInfer')\
                    .option('header','true')\
                        .schema(schema)\
                            .load(f'{landing_paths}/raw_traffic/')\
                                .withColumn('Extract_Time',current_timestamp()))
    
    print('Reading Succcess !!')
    print('*******************')

    return rawTraffic_stream

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create a read_raw_roads() function

# COMMAND ----------

def read_raw_roads():
    '''This Function is read the raw roads data from landing container'''
    schema = StructType([
        StructField('Road_ID',IntegerType()),
        StructField('Road_Category_Id',IntegerType()),
        StructField('Road_Category',StringType()),
        StructField('Region_ID',IntegerType()),
        StructField('Region_Name',StringType()),
        StructField('Total_Link_Length_Km',DoubleType()),
        StructField('Total_Link_Length_Miles',DoubleType()),
        StructField('All_Motor_Vehicles',DoubleType())
        ])
    
    df_rowRoad = spark.readStream\
        .format('cloudFiles')\
            .option('cloudFiles.format','csv')\
                .option('cloudFiles.schemaLocation',f'{check_points_path}/rawRoads/SchemaInfer/')\
                    .schema(schema)\
                        .load(f'{landing_paths}/raw_roads/')

    print('Reading Succcess !!')
    print('*******************')

    return df_rowRoad

# COMMAND ----------

# MAGIC %md
# MAGIC ##Write row_traffic Data to table and Bronze container

# COMMAND ----------

def write_raw_traffic(df,env):
    print('ENV:',env)
    '''This function write the data to bronze layer and raw_traffic table as a auto loader'''
    df_writeStream = df.writeStream.format('delta')\
        .option('checkpointLocation',f'{check_points_path}/rawTrafficLoad/checkPt')\
            .outputMode('append')\
                .queryName('rawTrafficWriteStreamBr')\
                    .trigger(availableNow=True)\
                        .toTable(f"`{env}_catalog`.`bronze`.`raw_traffic`")
    df_writeStream.awaitTermination()
    print("Write Success")
    print("**************************")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Write row_roads Data to table and Bronze container

# COMMAND ----------

def write_rawRoads(df,env):
    'This Functions is write the data to bronze layer and raw_roads table as a auto loader'
    df_WriteStream = df.writeStream.format('delta')\
        .option('checkpointLocation',f'{check_points_path}/rawRoads/checkPt/')\
            .queryName('rawRoadsWriteStream')\
                .trigger(availableNow = True)\
                    .toTable(f"`{env}_catalog`.`bronze`.`raw_roads`")
    df_WriteStream.awaitTermination()
    print("Write Success")
    print("******************************")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calling All the functions

# COMMAND ----------

##Raw Traffics
rawTraffic_df = read_Traffic_Data()
write_raw_traffic(rawTraffic_df,env)
##Raw Roads
rawRoads_df = read_raw_roads()
write_rawRoads(rawRoads_df,env)

# COMMAND ----------

if debug == 5:
    df_rawTraffic = spark.sql(f""" SELECT * FROM `{env}_catalog`.`bronze`.raw_traffic""")
    df_rawRoads = spark.sql(f""" SELECT * FROM `{env}_catalog`.`bronze`.raw_roads""")

    df_rawRoads.display()
    df_rawRoads.display()


# COMMAND ----------


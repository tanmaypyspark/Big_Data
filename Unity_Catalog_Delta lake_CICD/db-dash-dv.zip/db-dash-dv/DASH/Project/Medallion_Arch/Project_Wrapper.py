# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

##Input Param
dbutils.widgets.text('Parameter','')
param_dict = dbutils.widgets.get('Parameter')
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':5,'run_type':'Fresh Run'}
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':0,'run_type':'Prod','stage':'bronze'}

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import ast

# COMMAND ----------

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)
param

# COMMAND ----------

chk_point = param['CHKPoint']
chk_point_xt = param['CHKPointXT']
env = param['ENV']
debug = param['Debug']
stage = param['stage']

# if 'run_type' in param:
#     if param['run_type'] == 'Fresh Run':
#         try:
#             df_rawTraffic = spark.sql(f""" DELETE  FROM `{env}_catalog`.`bronze`.raw_traffic""")
#             df_rawRoads = spark.sql(f""" DELETE FROM `{env}_catalog`.`bronze`.raw_roads""")
#         except Exception as e:
#             print(f'Error: While deleting the table for Fresh Run {e}')

# COMMAND ----------

param

# COMMAND ----------

# MAGIC %md
# MAGIC ##Extracting the checkpoints, Bronze, Silver containers URLs

# COMMAND ----------

param['landing_paths'] = spark.sql(""" DESCRIBE EXTERNAL LOCATION `landing` """).select('url').collect()[0][0]
param['checkpoints'] = spark.sql(""" DESCRIBE EXTERNAL LOCATION `checkpoints` """).select('url').collect()[0][0]
param['source_path'] = spark.sql(""" DESCRIBE EXTERNAL LOCATION `bronze` """).select('url').collect()[0][0]
param['target_path'] =  spark.sql(""" DESCRIBE EXTERNAL LOCATION `silver` """).select('url').collect()[0][0]

# COMMAND ----------

# MAGIC %md
# MAGIC ##Executig Bronze Layer

# COMMAND ----------

##Load raw data to  Raw_TRAFFIC table using NOTEBOOK
if stage == 'BRONZE' or stage =='ALL':
    dbutils.notebook.run('/Workspace/Users/tanmaym.azure1@gmail.com/DASH/Project/Medallion_Arch/LOAD_TO_BRONZE',60,{'Parameter':json.dumps(param)})

# COMMAND ----------

# MAGIC %md
# MAGIC ##Execute Silver Layer

# COMMAND ----------

##Calling SILVER_TRAFFIC_TRANSFORMATION NOTEBOOK
if stage =='SILVER_TRAFFIC' or stage =='ALL':
    dbutils.notebook.run('/Workspace/Users/tanmaym.azure1@gmail.com/DASH/Project/Medallion_Arch/SILVER_TRAFFIC_TRANSFORMATION',0,{'Parameter':json.dumps(param)})

# COMMAND ----------

##Calling SILVER_ROADS TRANSFORMATION Notebook
if stage =='SILVER_ROADS' or stage == 'ALL':
    dbutils.notebook.run('/Workspace/Users/tanmaym.azure1@gmail.com/DASH/Project/Medallion_Arch/Silver_Roads_Transformatioon',0,{'Parameter':json.dumps(param)})

# COMMAND ----------

# MAGIC %md
# MAGIC ##Executing Gold Layer

# COMMAND ----------

##Calling Gold Transformation Notebook
if stage =='GOLD' or stage =='ALL':
    dbutils.notebook.run('/Workspace/Users/tanmaym.azure1@gmail.com/DASH/Project/Medallion_Arch/GOLD_Final_Transformation_And_Load',0,{'Parameter':json.dumps(param)})

# COMMAND ----------


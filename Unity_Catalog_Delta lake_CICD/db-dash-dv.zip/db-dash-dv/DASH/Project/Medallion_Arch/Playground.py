# Databricks notebook source
# MAGIC %sql
# MAGIC ---Count of Bronze Traffic Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`bronze`.`raw_traffic`

# COMMAND ----------

# MAGIC %sql
# MAGIC ---Count of Bronze Roads Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`bronze`.`raw_roads`

# COMMAND ----------

# MAGIC %sql
# MAGIC ---Count of Bronze Traffic Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`silver`.`silver_traffic`

# COMMAND ----------

# MAGIC %sql
# MAGIC ---Count of Bronze Traffic Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`silver`.`silver_roads`

# COMMAND ----------

# MAGIC %sql
# MAGIC ---Count of Bronze Traffic Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`gold`.`gold_traffic`

# COMMAND ----------

# MAGIC %sql
# MAGIC ---Count of Bronze Traffic Rows
# MAGIC SELECT COUNT(*) FROM `dev_catalog`.`gold`.`gold_roads`

# COMMAND ----------


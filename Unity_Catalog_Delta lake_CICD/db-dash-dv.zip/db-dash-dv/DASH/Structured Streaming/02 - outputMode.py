# Databricks notebook source
# MAGIC %sql
# MAGIC --USE hive_metastore.sales
# MAGIC select * from hive_metastore.stream.AppendTable;

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog stream_catalog;
# MAGIC show databases

# COMMAND ----------

dbutils.fs.rm('dbfs:/user/hive/warehouse/stream.db',True)
dbutils.fs.rm('/mnt/Streaming/raw/AppendCHECKPoint',True)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE IF EXISTS hive_metastore.stream CASCADE;
# MAGIC CREATE DATABASE IF NOT EXISTS hive_metastore.stream

# COMMAND ----------

stream_path = '/mnt/Streaming/raw/'
##When ever we are using Read Stream we have to define the schema/ InferSchema

from pyspark.sql.types import *
schema = StructType([
    StructField('Country', StringType()),
    StructField('Citizens', IntegerType())
])

# COMMAND ----------

df_r_stream = spark.readStream.format('csv').option('header','true').schema(schema).load(stream_path)

# COMMAND ----------

df_Streamwrite = df_r_stream.writeStream\
    .option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')\
        .outputMode('append')\
        .queryName('AppendQuery')\
            .toTable('hive_metastore.stream.AppendTable')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.stream.AppendTable;

# COMMAND ----------

df_Streamwrite.stop()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Complete

# COMMAND ----------

df_StreamwriteC = df_r_stream.writeStream\
    .option('checkpointLocation',f'{stream_path}/CompleteCHECKPoint')\
        .outputMode('complete')\
        .queryName('CompleteQuery')\
            .toTable('hive_metastore.stream.CompleteTable')

# COMMAND ----------

df_r_stream.printSchema()

# COMMAND ----------

from pyspark.sql.functions import sum
df_complete=df_r_stream.groupBy('Country').agg(sum('Citizens').alias('Total_Population'))

# COMMAND ----------

dbutils.fs.rm('dbfs:/user/hive/warehouse/stream.db/completetable',True)
dbutils.fs.rm('/mnt/Streaming/raw/CompleteCHECKPoint',True)

# COMMAND ----------

df_StreamwriteC = df_complete.writeStream\
    .option('checkpointLocation',f'{stream_path}/CompleteCHECKPoint')\
        .outputMode('complete')\
        .queryName('CompleteQuery')\
            .toTable('hive_metastore.stream.CompleteTable')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.stream.CompleteTable

# COMMAND ----------


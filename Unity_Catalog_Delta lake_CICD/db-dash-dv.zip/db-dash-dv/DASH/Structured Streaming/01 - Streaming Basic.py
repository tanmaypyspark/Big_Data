# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','Streaming/raw/') # Streaming / raw
source_path = dbutils.widgets.get('PATH')
#layer ce/schemaEvol/SchemaLessCols.csv
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','Countries1.csv')
file_name = dbutils.widgets.get('FILE')
# Countries1.csv

schemaLessCols = 'SchemaLessCols.csv'
schemaMoreCols = 'SchemaMoreCols.csv'
### CONF Details #####
conf = genConf()
root = conf['root']
stream_path = root+ source_path #+ file_name
stream_path

# COMMAND ----------

df_stream = spark.read.format('csv').option('header','true').load(stream_path)

# COMMAND ----------

df_stream.display()

# COMMAND ----------

# MAGIC %md
# MAGIC Read Stream Data

# COMMAND ----------

##When ever we are using Read Stream we have to define the schema/ InferSchema

from pyspark.sql.types import *
schema = StructType([
    StructField('Country', StringType()),
    StructField('Citizens', IntegerType())
])

# COMMAND ----------

df_r_stream = spark.readStream.format('csv').option('header','true').schema(schema).load(stream_path)

# COMMAND ----------

df_r_stream.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Stream write

# COMMAND ----------

# MAGIC %sql
# MAGIC --Create a Schema
# MAGIC CREATE SCHEMA IF NOT EXISTS stream_catalog.stream;
# MAGIC use stream_catalog.stream

# COMMAND ----------

# MAGIC %sql
# MAGIC --use hive metastore
# MAGIC CREATE SCHEMA IF NOT EXISTS hive_metastore.stream;
# MAGIC use hive_metastore.stream

# COMMAND ----------

writeStream = df_r_stream.writeStream\
    .option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')\
        .outputMode('append')\
            .queryName('AppendQuery')\
                .toTable("stream.AppendTable")

# COMMAND ----------

df_r_stream.writeStream\
    .option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')\
        .outputMode('append')\
            .queryName('AppendQuery')\
                .toTable("stream.AppendTable")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from stream.AppendTable;

# COMMAND ----------

writeStream.stop()

# COMMAND ----------


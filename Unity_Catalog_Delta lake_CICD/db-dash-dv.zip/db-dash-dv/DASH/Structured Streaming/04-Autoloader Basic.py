# Databricks notebook source
dbutils.fs.rm('dbfs:/user/hive/warehouse/stream.db',True)
dbutils.fs.rm('/mnt/Streaming/raw',True)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE IF EXISTS hive_metastore.stream CASCADE;
# MAGIC CREATE DATABASE IF NOT EXISTS hive_metastore.stream

# COMMAND ----------

stream_path = '/mnt/Streaming/raw/'
##When ever we are using Read Stream we have to define the schema/ InferSchema

from pyspark.sql.types import *
schema = StructType([
    StructField('Country', StringType()),
    StructField('Citizens', IntegerType())
])

# COMMAND ----------

df_r_stream = (spark.readStream
               .format('cloudFiles')
               .option('cloudFiles.format','csv')
               .option('cloudFiles.SchemaLocation',f'{stream_path}/schmeaInfer')
               .option('cloudFiles.inferColumnTypes','true')
               .option('header','true').load(stream_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ##SchemaHints

# COMMAND ----------

df_r_stream = (spark.readStream
               .format('cloudFiles')
               .option('cloudFiles.format','csv')
               .option('cloudFiles.SchemaLocation',f'{stream_path}/schmeaInfer')
               .option('cloudFiles.inferColumnTypes','true')
               .option('cloudFiles.schemaHints','Citizens Long')
               .option('header','true').load(stream_path))

# COMMAND ----------

df_r_stream.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Schema Evolution

# COMMAND ----------

# MAGIC %md
# MAGIC 01 - Rescue 

# COMMAND ----------

df_r_stream = (spark.readStream
               .format('cloudFiles')
               .option('cloudFiles.format','csv')
               .option('cloudFiles.SchemaLocation',f'{stream_path}/schmeaInfer')
               .option('cloudFiles.schemaEvolutionMode','rescue')
               .option('rescuedDataColumn','_rescued_data')
               .option('cloudFiles.inferColumnTypes','true')
               .option('cloudFiles.schemaHints','Citizens Long')
               .option('header','true').load(stream_path))

# COMMAND ----------

df_r_stream.display()

# COMMAND ----------

dbutils.fs.ls(f'{stream_path}/schmeaInfer/_schemas/')

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from json.`dbfs:/mnt/Streaming/raw/schmeaInfer/_schemas/0`

# COMMAND ----------

# MAGIC %md
# MAGIC #02 - addNewColumns- Default

# COMMAND ----------

df_r_stream = (spark.readStream
               .format('cloudFiles')
               .option('cloudFiles.format','csv')
               .option('cloudFiles.SchemaLocation',f'{stream_path}/schmeaInfer')
               .option('cloudFiles.inferColumnTypes','true')
               .option('cloudFiles.schemaHints','Citizens Long')
               .option('header','true').load(stream_path))

# COMMAND ----------

df_r_stream.display()

# COMMAND ----------

dbutils.fs.ls(f'{stream_path}/schmeaInfer/_schemas/')

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from json.`dbfs:/mnt/Streaming/raw/schmeaInfer/_schemas/1`

# COMMAND ----------

# MAGIC %md
# MAGIC ##03 FailOnNewColumn

# COMMAND ----------

dbutils.fs.ls(f'{stream_path}/schmeaInfer/_schemas/')

# COMMAND ----------

dbutils.fs.rm(f'{stream_path}/schmeaInfer/_schemas/1',True)

# COMMAND ----------

df_r_stream = (spark.readStream
               .format('cloudFiles')
               .option('cloudFiles.format','csv')
               .option('cloudFiles.SchemaLocation',f'{stream_path}/schmeaInfer')
               .option('cloudFiles.schemaEvolutionMode','failOnNewColumns')
               .option('cloudFiles.inferColumnTypes','true')
               .option('cloudFiles.schemaHints','Citizens Long')
               .option('header','true').load(stream_path))

# COMMAND ----------

df_r_stream.display()

# COMMAND ----------

dbutils.fs.ls(f'{stream_path}/schmeaInfer/_schemas/')

# COMMAND ----------


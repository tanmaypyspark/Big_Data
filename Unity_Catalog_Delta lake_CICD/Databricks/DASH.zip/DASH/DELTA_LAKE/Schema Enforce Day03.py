# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','deltalake/source/')
source_path = dbutils.widgets.get('PATH')
#layer ce/schemaEvol/SchemaLessCols.csv
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','schemaEvol')
file_name = dbutils.widgets.get('FILE')
# deltalake / target / delta / deltaFolder

schemaLessCols = 'SchemaLessCols.csv'
schemaMoreCols = 'SchemaMoreCols.csv'
### CONF Details #####
conf = genConf()
root = conf['root']
delta_path = root+ source_path + file_name

# COMMAND ----------

delta_path

# COMMAND ----------

# MAGIC %md
# MAGIC #Read Less Columns

# COMMAND ----------

schema1 = StructType([
    StructField('Education_Level',StringType()),
    StructField('Line_Number',IntegerType()),
    StructField('Employed',IntegerType()),
    StructField('Unemployed',IntegerType()),
    StructField('Industry',StringType()),
    StructField('Gender',StringType()),
    StructField('Date_Inserted',StringType()),
    StructField('dense_rank',IntegerType()),
    StructField('Max_Salary_USD',IntegerType())
])

# COMMAND ----------

df_more = spark.read.format('csv')\
    .schema(schema1)\
        .load(os.path.join(delta_path,schemaMoreCols))

# COMMAND ----------

df_more.printSchema()

# COMMAND ----------

df_more.write.format('delta').mode('append').saveAsTable('`delta`.deltaspark')

# COMMAND ----------

schema2 = StructType([
    StructField('Education_Level',StringType()),
    StructField('Line_Number',IntegerType()),
    StructField('Employed',IntegerType()),
    StructField('Unemployed',IntegerType()),
    StructField('Industry',StringType()),
    StructField('Gender',StringType())
])

# COMMAND ----------

df_less = spark.read.format('csv')\
    .schema(schema2)\
        .load(os.path.join(delta_path,schemaLessCols))

# COMMAND ----------

df_less.display()

# COMMAND ----------

df_less.write.format('delta').mode('append').saveAsTable('`delta`.deltaspark')

# COMMAND ----------

df_diff = spark.read.format('csv')\
    .option('header','true')\
        .load(os.path.join(delta_path,'*.csv'))

# COMMAND ----------

df_diff.write.format('delta').mode('append').saveAsTable('`delta`.deltaspark')

# COMMAND ----------

# MAGIC %md
# MAGIC #Schema Evolution

# COMMAND ----------

df_more.write.format('delta').mode('append').option('mergeSchema','true').saveAsTable('`delta`.deltaspark')

# COMMAND ----------

# MAGIC %md
# MAGIC #All different data types

# COMMAND ----------

df_diff.write.format('delta').option('overwriteSchema','true').mode('overwrite').saveAsTable('`delta`.deltaspark')

# COMMAND ----------

df_diff.printSchema()

# COMMAND ----------



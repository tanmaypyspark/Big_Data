# Databricks notebook source
# MAGIC %run ../../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('PATH','deltalake/medallion_arch/')
source_path = dbutils.widgets.get('PATH')
#layer
dbutils.widgets.dropdown("state", "bronze", ["bronze", "silver", "gold"])
layer = dbutils.widgets.get('state')
#File
dbutils.widgets.text('FILE','')
file_name = dbutils.widgets.get('FILE')
#deltalake/medallion_arch/bronze/SchemaManagementDelta.csv

# COMMAND ----------

### CONF Details #####
conf = genConf()
root = conf['root']

# COMMAND ----------

path = root+source_path+layer+'/'+file_name

# COMMAND ----------

schema1 = StructType([
    StructField('Education_Level',StringType()),
    StructField('Line_Number',IntegerType()),
    StructField('Employed',IntegerType()),
    StructField('Unemployed',IntegerType()),
    StructField('Industry',StringType()),
    StructField('Gender',StringType()),
    StructField('Date_Inserted',StringType()),
    StructField('dense_rank',IntegerType())
])

# COMMAND ----------

schema_df = spark.read.format('csv')\
    .option('header','True')\
        .schema(schema1)\
            .load(path)

# COMMAND ----------

target_par_path =root+ 'deltalake/target/parq'+'/ParqutFolder'

# COMMAND ----------

schema_df.printSchema()

# COMMAND ----------

schema_df.write.format('parquet')\
    .mode('overwrite')\
        .save(target_par_path)

# COMMAND ----------

schema_df1 = schema_df.filter("Education_Level=='High School'")

# COMMAND ----------

schema_df1.write.format('parquet').mode('overwrite').save(target_par_path)

# COMMAND ----------

 par_df = spark.read.format('parquet').load(target_par_path)

# COMMAND ----------

par_df.printSchema()

# COMMAND ----------

par_df.createOrReplaceTempView('par_tbl')

# COMMAND ----------

# MAGIC %sql
# MAGIC update par_tbl
# MAGIC set Education_Level = 'High School'
# MAGIC where Education_Level= 'High School Diploma'

# COMMAND ----------

# MAGIC %md
# MAGIC #Delta

# COMMAND ----------

delta_path = target_par_path.replace('parq','delta').replace('ParqutFolder','deltaFolder')

# COMMAND ----------

schema_df.rdd.getNumPartitions()

# COMMAND ----------

schema_df = schema_df.repartition(3)

# COMMAND ----------

schema_df.write.format('delta').mode('overwrite').save(delta_path)

# COMMAND ----------

#delta_df = spark.read.format('parquet').load(f'{delta_path}/*.parquet')
# [DELTA_INVALID_FORMAT] Incompatible format detected.

# A transaction log for Delta was found at `/mnt/deltalake/target/delta/deltaFolder/_delta_log`,
# but you are trying to read from `/mnt/deltalake/target/delta/deltaFolder/*.parquet` using format("parquet"). You must use
# 'format("delta")' when reading and writing to a delta table.

# COMMAND ----------

dbutils.fs.ls(delta_path)

# COMMAND ----------

dbutils.fs.ls(f'{delta_path}/_delta_log')

# COMMAND ----------

display(spark.read.format('text').load('dbfs:/mnt/deltalake/target/delta/deltaFolder/_delta_log/00000000000000000002.json'))

# COMMAND ----------

delta_df = spark.read.format('delta').load(delta_path)

# COMMAND ----------

delta_df.display()

# COMMAND ----------

df_delata1 = delta_df.filter("Education_Level=='High School'")

# COMMAND ----------

df_delata1 = df_delata1.repartition(2)

# COMMAND ----------

# MAGIC %md
# MAGIC #Overwrite The dame file in delta folder

# COMMAND ----------

df_delata1.write.format('delta').mode('overwrite').save(delta_path)

# COMMAND ----------

# MAGIC %md
# MAGIC #Read Overwrite file

# COMMAND ----------

df_overwrite = spark.read.format('delta').load(delta_path)

# COMMAND ----------

df_overwrite.display()

# COMMAND ----------



# Databricks notebook source
dbutils.fs.rm('dbfs:/user/hive/warehouse/stream.db',True)
dbutils.fs.rm('/mnt/Streaming/raw',True)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE IF EXISTS hive_metastore.stream CASCADE;
# MAGIC CREATE DATABASE IF NOT EXISTS hive_metastore.stream

# COMMAND ----------

stream_path = '/mnt/Streaming/raw/'
##When ever we are using Read Stream we have to define the schema/ InferSchema

from pyspark.sql.types import *
schema = StructType([
    StructField('Country', StringType()),
    StructField('Citizens', IntegerType())
])

# COMMAND ----------

# MAGIC %md
# MAGIC Reading the streaming Dataframe

# COMMAND ----------

df_r_stream = spark.readStream.format('csv').option('header','true').schema(schema).load(stream_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ##01. Trigger - default or unspecified Trigger 

# COMMAND ----------

df_writeStream = (df_r_stream.writeStream
.option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')
.outputMode('append')
.queryName('DefaultTrigger')
.toTable('hive_metastore.stream.AppendTable'))

# COMMAND ----------

# MAGIC %md
# MAGIC ##02 Triggers- ProcessingTime

# COMMAND ----------

df_writeStream = (df_r_stream.writeStream
.option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')
.outputMode('append')
.trigger(processingTime='2 minutes')
.queryName('ProcessingTimeTrigger')
.toTable('hive_metastore.stream.AppendTable'))

# COMMAND ----------

# MAGIC %md
# MAGIC ##03 Triggers- Availablenow

# COMMAND ----------

dbutils.fs.rm(f'{stream_path}/AppendCHECKPoint',True)

# COMMAND ----------

df_writeStream = (df_r_stream.writeStream
.option('checkpointLocation',f'{stream_path}/AppendCHECKPoint')
.outputMode('append')
.trigger(availableNow=True)
.queryName('AvailableNow')
.toTable('hive_metastore.stream.AppendTable'))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.stream.appendtable

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table hive_metastore.stream.appendtable

# COMMAND ----------



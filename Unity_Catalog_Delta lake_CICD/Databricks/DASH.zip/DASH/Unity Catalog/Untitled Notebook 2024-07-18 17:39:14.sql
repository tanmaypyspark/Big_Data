-- Databricks notebook source
GRANT USE_CATALOG ON CATALOG `dev_catalog` TO `Developers G`

-- COMMAND ----------

GRANT SELECT ON CATALOG `dev_catalog` TO `Developers G`

-- COMMAND ----------

CREATE TABLE Persons(
  PersonID INT,
  LastName VARCHAR(30),
  FirstName VARCHAR(30),
  Address VARCHAR(50)
)

-- COMMAND ----------



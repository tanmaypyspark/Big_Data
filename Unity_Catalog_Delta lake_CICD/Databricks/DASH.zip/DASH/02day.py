# Databricks notebook source
import pandas as pd

# COMMAND ----------

#Sample data with a missing value
data = {'date_time': ['     20-JUN-2024 09:00:00.0000000 AM', ' ','     22-JUL-2024 11:30:15.1234567 AM', ' ']}
df = pd.DataFrame(data)

# COMMAND ----------

print(df)

# COMMAND ----------

def process_date_time(dt_str):
  # Try converting, return NaN if unsuccessful (for missing value)
  try:
    return pd.to_datetime(dt_str).dt.strftime('%d-%m-%y')
  except:
    return pd.NA

# Apply the function to 'date_time' with error handling
df['date'] = df['date_time'].apply(process_date_time)

# COMMAND ----------

print(df)

# COMMAND ----------

df['d'] =pd.to_datetime(df['date_time'], errors='coerce').dt.strftime('%d-%m-%y')

# COMMAND ----------

print(df)

# COMMAND ----------

# MAGIC %run ../COMMON/Conf

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys

# COMMAND ----------

dbutils.notebook.run('/Workspace/Users/tanmaym.azure1@gmail.com/COMMON/Mount_Storage',timeout_seconds=60,arguments={'container_name':'practice','mount_point':'/mnt/practice/'})

# COMMAND ----------

# MAGIC %md
# MAGIC Infinite Research InterView Question

# COMMAND ----------

path = '/mnt/practice'+'/row/'

# COMMAND ----------

dbutils.fs.ls(path)

# COMMAND ----------

emp_df = spark.read.format('csv').option('header','true').option('inferSchema','true').load(path)

# COMMAND ----------

emp_df.display()

# COMMAND ----------

emp_df.createOrReplaceTempView('emp1')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from emp1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from emp1
# MAGIC where salary = (SELECT AVG(max_min_salary) AS avg_salary_sum
# MAGIC FROM (
# MAGIC     SELECT MAX(salary) + MIN(salary) AS max_min_salary
# MAGIC     FROM emp1
# MAGIC ) AS subquery)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT AVG(max_min_salary) AS avg_salary_sum
# MAGIC FROM (
# MAGIC     SELECT MAX(salary) + MIN(salary) AS max_min_salary
# MAGIC     FROM emp1
# MAGIC ) AS subquery

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from emp
# MAGIC where sal = (select avg(max(sal),min(sal)) from emp group by dept)

# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

##Input Param to run the notebook
dbutils.widgets.text('Parameter','')
param_dict = dbutils.widgets.get('Parameter')
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':5,'run_type':'Fresh Run'}

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import ast
import datetime

# COMMAND ----------

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)

# COMMAND ----------

param

# COMMAND ----------

env= param['ENV']
checkpoints = param['checkpoints']
source_path = param['source_path']
target_path = param['target_path']
debug = param['Debug']

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read Bronze container Files

# COMMAND ----------


def read_Bronze_Data():
    print('Reading is in progress....')
    df_read = spark.readStream.format('delta')\
    .table("`dev_catalog`.bronze.raw_traffic")
    print('Reading is in progress:', end=' ')
    print('Success !!')
    return df_read

# COMMAND ----------

# MAGIC %md
# MAGIC ##Renaming The column
# MAGIC ### If the dataset column name is comming without '_' we are gonna replace that with '_'. E.g. 'Record ID'--> 'Record_ID'

# COMMAND ----------

def rename_Column(df):
    'This function is to rename the columns'
    print('Rename The Columns: ', end=' ')

    all_columns = df.schema.names
    #df.limit(1).display()
    for column in all_columns:
        if '_' not in column:
            new_column = column.replace(' ','_')
            df = df.withColumnRenamed(column,new_column)
    print('Success!!! ')
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ##**Handling Duplicate rows**

# COMMAND ----------

def remove_duplicates(df):
    'This function is use to drop duplicates data '
    print('Removing Duplicates values: ', end=' ')

    df_dup = df.dropDuplicates()
    print('success!! ')
    return df_dup

# COMMAND ----------

# MAGIC %md
# MAGIC ##**Handling Null Values by replacing them**

# COMMAND ----------

def handle_NULLS(df,columns):
    'This function is use to handle NULL values'
    
    print('Replacing NULL values on string columns with "Unknown" ', end = ' ')
    df_N_Str = df.fillna('Unknown',subset = columns)
    print('Success!!! ')

    print('Replacing NULL value on Numeric Columns with "0" ', end = ' ')
    df_N_Num = df_N_Str.fillna(0,subset = columns)
    print('Success!!! ')

    return df_N_Num


# COMMAND ----------

# MAGIC %md
# MAGIC ##Creating Electric_Vehicles_Count

# COMMAND ----------

def ev_Count(df):
    'This function is use to count the total EV Cars and Bikes'
    
    print('Creating Electric Vehicles Count Column ', end=' ')
    df_ev = df.withColumn('Electric_Vehicles_Count',(col('EV_Car') +  col('EV_Bike')))
    print('Success !!! ')

    return df_ev

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Motor_Vehicles_Counts

# COMMAND ----------

def motor_Vehicles_Count(df):
    'This function is use to count the total Motor Vehicles '
    print('Creating Motor Vehicles Count Column: ', end= ' ')

    df_motor = df.withColumn('Motor_Vehicles_Count',
                             (
                                 col('Two_wheeled_motor_vehicles')
                                 +
                                 col('Cars_and_taxis')
                                 +
                                 col('Buses_and_coaches')
                                 +
                                 col('LGV_Type')
                                 +
                                 col('HGV_Type')
                                 +
                                 col('Electric_Vehicles_Count')
                                 )
                             )
    print('Success !!!!')
    return df_motor

# COMMAND ----------

# MAGIC %md
# MAGIC ##Creating A Transformation Columns

# COMMAND ----------

def create_TimeStamp(df):
    'This functions is use to maintain the Time Stamp'
    print('Creating Transformation Time Column: ', end=' ')

    df_Final = df.withColumn('Transformation_Time', current_timestamp())
    print('Success !!!')

    return df_Final

# COMMAND ----------

# MAGIC %md
# MAGIC ##Write the Transformaed data to Silver_Traffic Table

# COMMAND ----------

def write_Traffic_SilverTables(StreamDf, env, debug = 0):
    'This Function is gonna write the data in delta tables as well as in ADLS if debug is 5'
    print('Writting the silver_Traffic Data....')
    
    df_write = (StreamDf.writeStream
     .format('delta')
     .option('checkpointLocation', f'{checkpoints}/SilverTrafficLoad/Checkpt')
     .outputMode('append')
     .queryName('SilverTrafficWriteStream')
     .trigger(availableNow = True)
     .toTable(f"`{env}_catalog`.`silver`.`silver_traffic`"))
    
    df_write.awaitTermination()
    print('Writting the silver_Traffic Data:', end = ' ')
    print('Success!!! ')
    
    if debug ==5:
        print('Write to ADLS Silver Path......')
        time_stamp = datetime.datetime.utcnow()
        print('TimeStamp: ', time_stamp)
        df_Adls = (StreamDf.writeStream
               .format('delta')
               .option('mergeSchema','true')
               .option('checkpointLocation',f'{checkpoints}/Debug/SilverTrafficLoad/{time_stamp}/')
               .outputMode('append')
               .trigger(availableNow = True)
               .start(f'{target_path}/Debug/SilverTrafficLoad/{time_stamp}/')
            )
        df_Adls.awaitTermination()



# COMMAND ----------

# MAGIC %md
# MAGIC ##Calling All the Functions

# COMMAND ----------

##Calling All The Functions

#Read the data
df_Bz_Traffic = read_Bronze_Data()

#Rename The Column:
df_Rename = rename_Column(df_Bz_Traffic)

#To Removes duplicates
df_dups = remove_duplicates(df_Rename)

#Handle NULLs
all_cloumns = df_dups.schema.names
df_Null = handle_NULLS(df_dups, all_cloumns)

##Total Count
df_count = ev_Count(df_Null)

##Motor Vehicles Count
df_motor_count = motor_Vehicles_Count(df_count)

##Create TimeStamp
df_Final = create_TimeStamp(df_motor_count)

##Write the Data into Tables
write_Traffic_SilverTables(df_Final, env, debug)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC

# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

##Input Param to run the notebook
dbutils.widgets.text('Parameter',"{'null':'null'}")
param_dict = dbutils.widgets.get('Parameter')
#{'CHKPoint':'checkpoints', 'CHKPointXT':'','ENV':'dev','Debug':5,'run_type':'Fresh Run'}

# COMMAND ----------

param_dict

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import ast
import datetime

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)
param

# COMMAND ----------

env= param['ENV']
checkpoints = param['checkpoints']
source_path = param['source_path']
target_path = param['target_path']
debug = param['Debug']

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read Data from bornze Table

# COMMAND ----------

def read_bronze_Data(env):
    print('Reading is in progress....')
    
    df = spark.readStream\
        .format('delta')\
            .table(f"`{env}_catalog`.`bronze`.`raw_roads`")
    
    print('Reading is in progress:', end=' ')
    print('Success !!')
    return df

# COMMAND ----------

##Rename The column
def rename_Column(df):
    'This function is to rename the columns'
    print('Rename The Columns: ', end=' ')

    all_columns = df.schema.names
    #df.limit(1).display()
    for column in all_columns:
        if '_' not in column:
            new_column = column.replace(' ','_')
            df = df.withColumnRenamed(column,new_column)
    print('Success!!! ')
    return df

# COMMAND ----------

##Remove duplicates
def remove_duplicates(df):
    'This function is use to drop duplicates data '
    print('Removing Duplicates values: ', end=' ')

    df_dup = df.dropDuplicates()
    print('success!! ')
    return df_dup

# COMMAND ----------

def handle_NULLS(df,columns):
    'This function is use to handle NULL values'
    
    print('Replacing NULL values on string columns with "Unknown" ', end = ' ')
    df_N_Str = df.fillna('Unknown',subset = columns)
    print('Success!!! ')

    print('Replacing NULL value on Numeric Columns with "0" ', end = ' ')
    df_N_Num = df_N_Str.fillna(0,subset = columns)
    print('Success!!! ')

    return df_N_Num


# COMMAND ----------

##Creating Road_Category_Name column
def roadCategoryNamy(df):
    print("Creating Road Category Name:", end= ' ')

    road_name = when(col('Road_Category')=='TA', lit('Class A Trunk Road'))\
        .otherwise(
            when(col('Road_Category')=='TM', lit('Class A Trunk Motor'))\
                .otherwise(
                    when(col('Road_Category')=='PA', lit('Class A Principal Road'))\
                    .otherwise(
                        when(col('Road_Category')=='PM', lit('Class A Principal Motorway'))\
                        .otherwise(
                            when(col('Road_Category')=='M', lit('Class B Road')).otherwise(lit('NA'))\
                                )
                               )
                           )
        )

    df = df.withColumn('Road_Category_Name', road_name)
    print('Success!!!')
    return df

# COMMAND ----------

##Road Type
def createRoadTyp(df):
    print('Creating Road Type Column: ', end=' ')

    road_typ = when(col('Road_Category_Name').contains('Class A'), lit('Major'))\
        .otherwise(
            when(col('Road_Category_Name').contains('Class B'), lit('Minor')).otherwise(lit('NA'))\
                )
    df = df.withColumn('Road_Type',road_typ)
    print('Success!!! ')

    return df

# COMMAND ----------

##Writing to the silver_roads tables

def writting_Silver_Roads(streamDF, env,debug=0):
    print('Writting to silver roads tables...')

    df_streamDF = streamDF.writeStream\
        .format('delta')\
            .option('checkpointLocation',f'{checkpoints}/SilverRoads/Checkpt')\
                .outputMode('append')\
                    .queryName('SilverRoadWriteStream')\
                        .trigger(availableNow = True)\
                            .toTable(f"`{env}_catalog`.`silver`.`silver_roads`")
    
    df_streamDF.awaitTermination()
    print('Writting the silver_roads Data:', end = ' ')
    print('Success!!! ')
    
    if debug ==5:
        print('Write to ADLS Silver Path......')
        time_stamp = datetime.datetime.utcnow()
        print('TimeStamp: ', time_stamp)
        df_Adls = (streamDF.writeStream
               .format('delta')
               .option('mergeSchema','true')
               .option('checkpointLocation',f'{checkpoints}/Debug/SilverRoads/{time_stamp}/')
               .outputMode('append')
               .trigger(availableNow = True)
               .start(f'{target_path}/Debug/SilverRoads/{time_stamp}/')
            )
        df_Adls.awaitTermination()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Calling All the FUNCTIONS

# COMMAND ----------

##Read the raw data
df_raw_roads= read_bronze_Data(env)

##Rename the column
df_rename = rename_Column(df_raw_roads)

##

#To Removes duplicates
df_dups = remove_duplicates(df_rename)

#Handle NULLs
all_cloumns = df_dups.schema.names
df_Null = handle_NULLS(df_dups, all_cloumns)

##Create Road Category Name
df_Road_category = roadCategoryNamy(df_Null)

## Create Road Type
df_roadTyp = createRoadTyp(df_Road_category)

##Write to table
df_final = writting_Silver_Roads(df_roadTyp, env, debug)


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from `dev_catalog`.`silver`.`silver_roads`;

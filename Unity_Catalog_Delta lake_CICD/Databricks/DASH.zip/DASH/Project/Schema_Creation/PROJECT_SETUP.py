# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

import json
import ast

# COMMAND ----------

dbutils.widgets.text('Parameter','')
param_dict = dbutils.widgets.get('Parameter')
# '{'catalog':'dev_catalog','schema':['bronze','silver','gold'],'container':'medallion','storage_acc':'sa202401dv'}'

# COMMAND ----------

try:
    param = json.loads(param_dict)
except:
    param = ast.literal_eval(param_dict)

# COMMAND ----------

#Parameter
cLog = param['catalog']
schemaList = param['schema']
container = param['container']
storage = param['storage_acc']

# COMMAND ----------

print(f'Using {cLog} ')
spark.sql(f""" USE CATALOG {cLog} """)

# COMMAND ----------

def create_schema(schemaList):
    for sc in schemaList:
        print(f'Creating {sc} Schema in {cLog}')
        exPath = spark.sql(f""" DESCRIBE EXTERNAL LOCATION `{sc}`  """).select('url').collect()[0][0]
        spark.sql(f""" CREATE SCHEMA IF NOT EXISTS `{sc}` 
              MANAGED LOCATION '{exPath}/{sc}'
              """)
    print("************************************")
    

# COMMAND ----------

create_schema(schemaList)

# COMMAND ----------

def create_raw_tables(cLog, sc):
    print(f"Creating raw_Traffic table in {cLog}")
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{cLog}`.`{sc}`.`raw_traffic`
                        (
                            Record_ID INT,
                            Count_point_id INT,
                            Direction_of_travel VARCHAR(255),
                            Year INT,
                            Count_date VARCHAR(255),
                            hour INT,
                            Region_id INT,
                            Region_name VARCHAR(255),
                            Local_authority_name VARCHAR(255),
                            Road_name VARCHAR(255),
                            Road_Category_ID INT,
                            Start_junction_road_name VARCHAR(255),
                            End_junction_road_name VARCHAR(255),
                            Latitude DOUBLE,
                            Longitude DOUBLE,
                            Link_length_km DOUBLE,
                            Pedal_cycles INT,
                            Two_wheeled_motor_vehicles INT,
                            Cars_and_taxis INT,
                            Buses_and_coaches INT,
                            LGV_Type INT,
                            HGV_Type INT,
                            EV_Car INT,
                            EV_Bike INT,
                            Extract_Time TIMESTAMP
                    );""")
    
    print(f'Creating raw_roads table in {cLog}')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{cLog}`.`{sc}`.`raw_roads`
                        (
                            Road_ID INT,
                            Road_Category_Id INT,
                            Road_Category VARCHAR(255),
                            Region_ID INT,
                            Region_Name VARCHAR(255),
                            Total_Link_Length_Km DOUBLE,
                            Total_Link_Length_Miles DOUBLE,
                            All_Motor_Vehicles DOUBLE
                    );""")
    
    print("************************************")

# COMMAND ----------

##Schema Creation
create_schema(schemaList)

##Create Bronze tables
create_raw_tables(cLog,'bronze')

# COMMAND ----------


